{
    "application-id" : "robots",
    "node": {
        "name": "robot1-node",        
        "composition-file": "composition.js"
    },
    "transport": [
        "xmpp"
    ],
    "transport-xmpp": {
        "xmpp-port": 5222,
        "xmpp-jid": "bot@charmanson.isandlatech.com",
        "xmpp-server": "charmanson.isandlatech.com"
    }
}