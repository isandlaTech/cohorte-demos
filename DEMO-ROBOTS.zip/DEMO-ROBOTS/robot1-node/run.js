{
    "application-id": "robots",
    "node": {
        "shell-admin": 0,
        "top-composer": false,
        "use-cache": false,
        "name": "robot1-node",
        "web-admin": 0
    },
    "transport": [
        "http"
    ]
}