{
    "application-id": "robots",
    "transport": [
        "http"
    ],
    "node": {
        "top-composer": true,
        "shell-admin": 0,
        "use-cache": false,
        "auto-start": true,
        "composition-file": "composition.js",
        "name": "controller-node",
        "web-admin": 9000
    }
}