/* WARNING!: do not edit, this file is generated automatically by COHORTE startup scripts. */
{
    "import-files" : [ "all-xmpp.js" ],
    "composition" : [
    {
        "name" : "herald-xmpp-transport",
        "properties" : {
            "xmpp.server" : "charmanson.isandlatech.com",
            "xmpp.port" : "5222",
            "xmpp.monitor.jid" : "bot@charmanson.isandlatech.com",
            "xmpp.room.jid" : "cohorte@conference.charmanson.isandlatech.com",
            "xmpp.monitor.key" : "42"
        }
    }
    ]
}
