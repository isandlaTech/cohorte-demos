{
    "node": {
        "use-cache": false,
        "name": "robot2-node",
        "web-admin": 0,
        "shell-admin": 0,
        "top-composer": false
    },
    "transport": [
        "http"
    ],
    "application-id": "robots"
}