/* WARNING!: do not edit, this file is generated automatically by COHORTE startup scripts. */
{
    "import-files" : [ "python-top.js" ],
    "composition" : [
    {
        "factory" : "cohorte-composer-top-factory",
        "name" : "cohorte-composer-top",
        "properties" : {
            "autostart" : "True",
            "composition.filename" : "composition.js"
        }
    }
    ]
}
