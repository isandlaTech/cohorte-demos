{
    "application-id": "led",
    "node": {
	"recomposition-delay": 120,
        "name": "led-desktop"
    },
    "transport": [
        "xmpp"
    ],
    "transport-xmpp": {
        "xmpp-server": "charmanson.isandlatech.com",
        "xmpp-jid": "bot@charmanson.isandlatech.com",
        "xmpp-port": 5222
    }
}
