{
 "application-id": "led",
 "node": {
  "use-cache": "true",
  "name": "led-arduino-yun",
  "interpreter": "python",
  "recomposition-delay": 120
 },
 "transport": [ "xmpp" ],
 "transport-xmpp": {    
    "xmpp-server": "charmanson.isandlatech.com",
    "xmpp-jid": "bot@charmanson.isandlatech.com",
    "xmpp-port": 5222
 }
}

