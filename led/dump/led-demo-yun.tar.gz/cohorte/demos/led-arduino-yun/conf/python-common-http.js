/* WARNING!: do not edit, this file is generated automatically by COHORTE startup scripts. */
{
    "import-files" : [ "python-common-http.js" ],
    "composition" : [
    {
        "name" : "pelix-http-service",
        "properties" : {
            // Use the IPv4 stack
            "pelix.http.address" : "0.0.0.0"
        }
    }
    ]
}
