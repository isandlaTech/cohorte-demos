/* WARNING!: do not edit, this file is generated automatically by COHORTE startup scripts. */
{
    "import-files" : [ "java-xmpp.js" ]
}
