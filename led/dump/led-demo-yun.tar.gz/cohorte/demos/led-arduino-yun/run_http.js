{
 "application-id": "led",
 "node": {
  "use-cache": "true",
  "name": "led-arduino-yun",
  "interpreter": "python",
  "recomposition-delay": 220
 },
 "transport": [ "http" ],
 "transport-http": {    
    "http-ipv": 4
 }
}

