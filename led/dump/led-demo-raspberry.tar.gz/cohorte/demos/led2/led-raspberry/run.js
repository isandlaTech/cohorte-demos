{
    "node": {
        "use-cache": "true",
        "name": "led-raspberry",
        "top-composer": false,
        "interpreter": "python",
        "web-admin": 0,
        "recomposition-delay": 50,
        "shell-admin": 0
    },
    "application-id": "led2",
    "transport-http": {
        "http-ipv": 4
    },
    "transport": [
        "http"
    ]
}