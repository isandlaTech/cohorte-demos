{
    "directories": [
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0279", 
            "pkg_name": "sleekxmpp.plugins.xep_0279"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/xmlstream/matcher", 
            "pkg_name": "sleekxmpp.xmlstream.matcher"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/features/feature_starttls", 
            "pkg_name": "sleekxmpp.features.feature_starttls"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/google/settings", 
            "pkg_name": "sleekxmpp.plugins.google.settings"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/jsonrpclib", 
            "pkg_name": "jsonrpclib"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/test", 
            "pkg_name": "sleekxmpp.test"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/thirdparty", 
            "pkg_name": "sleekxmpp.thirdparty"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/composer/node/criteria/reliability", 
            "pkg_name": "cohorte.composer.node.criteria.reliability"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/pelix/pelix/services", 
            "pkg_name": "pelix.services"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0077", 
            "pkg_name": "sleekxmpp.plugins.xep_0077"
        }, 
        {
            "dir_name": "/home/pi/cohorte/demos/led2/led-raspberry/repo/led_uno_wrapper/led_uno_wrapper", 
            "pkg_name": "led_uno_wrapper"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0071", 
            "pkg_name": "sleekxmpp.plugins.xep_0071"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/google/nosave", 
            "pkg_name": "sleekxmpp.plugins.google.nosave"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0172", 
            "pkg_name": "sleekxmpp.plugins.xep_0172"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0078", 
            "pkg_name": "sleekxmpp.plugins.xep_0078"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0030/stanza", 
            "pkg_name": "sleekxmpp.plugins.xep_0030.stanza"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/features/feature_session", 
            "pkg_name": "sleekxmpp.features.feature_session"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins", 
            "pkg_name": "sleekxmpp.plugins"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/composer/top", 
            "pkg_name": "cohorte.composer.top"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte", 
            "pkg_name": "cohorte"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/vote", 
            "pkg_name": "cohorte.vote"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0080", 
            "pkg_name": "sleekxmpp.plugins.xep_0080"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/xmlstream", 
            "pkg_name": "sleekxmpp.xmlstream"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0086", 
            "pkg_name": "sleekxmpp.plugins.xep_0086"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/debug", 
            "pkg_name": "cohorte.debug"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0084", 
            "pkg_name": "sleekxmpp.plugins.xep_0084"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0085", 
            "pkg_name": "sleekxmpp.plugins.xep_0085"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0249", 
            "pkg_name": "sleekxmpp.plugins.xep_0249"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0004", 
            "pkg_name": "sleekxmpp.plugins.xep_0004"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/features/feature_mechanisms/stanza", 
            "pkg_name": "sleekxmpp.features.feature_mechanisms.stanza"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0009", 
            "pkg_name": "sleekxmpp.plugins.xep_0009"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/forker/starters", 
            "pkg_name": "cohorte.forker.starters"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/features/feature_mechanisms", 
            "pkg_name": "sleekxmpp.features.feature_mechanisms"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/repositories/java", 
            "pkg_name": "cohorte.repositories.java"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/requests/requests/packages/urllib3/packages/ssl_match_hostname", 
            "pkg_name": "requests.packages.urllib3.packages.ssl_match_hostname"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/util", 
            "pkg_name": "sleekxmpp.util"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/herald/herald/transports/xmpp", 
            "pkg_name": "herald.transports.xmpp"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0313", 
            "pkg_name": "sleekxmpp.plugins.xep_0313"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0095", 
            "pkg_name": "sleekxmpp.plugins.xep_0095"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0096", 
            "pkg_name": "sleekxmpp.plugins.xep_0096"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0091", 
            "pkg_name": "sleekxmpp.plugins.xep_0091"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0319", 
            "pkg_name": "sleekxmpp.plugins.xep_0319"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/util/sasl", 
            "pkg_name": "sleekxmpp.util.sasl"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/herald/herald/transports", 
            "pkg_name": "herald.transports"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/pelix/pelix/ipopo", 
            "pkg_name": "pelix.ipopo"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte", 
            "pkg_name": "cohorte"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0118", 
            "pkg_name": "sleekxmpp.plugins.xep_0118"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0050", 
            "pkg_name": "sleekxmpp.plugins.xep_0050"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0323/stanza", 
            "pkg_name": "sleekxmpp.plugins.xep_0323.stanza"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0054", 
            "pkg_name": "sleekxmpp.plugins.xep_0054"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0059", 
            "pkg_name": "sleekxmpp.plugins.xep_0059"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0297", 
            "pkg_name": "sleekxmpp.plugins.xep_0297"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0115", 
            "pkg_name": "sleekxmpp.plugins.xep_0115"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp", 
            "pkg_name": "sleekxmpp"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/boot/looper", 
            "pkg_name": "cohorte.boot.looper"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/features", 
            "pkg_name": "sleekxmpp.features"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0186", 
            "pkg_name": "sleekxmpp.plugins.xep_0186"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/boot/loaders", 
            "pkg_name": "cohorte.boot.loaders"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0184", 
            "pkg_name": "sleekxmpp.plugins.xep_0184"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/webadmin/webadmin", 
            "pkg_name": "webadmin"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/composer/node/criteria", 
            "pkg_name": "cohorte.composer.node.criteria"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/requests/requests/packages/urllib3/packages", 
            "pkg_name": "requests.packages.urllib3.packages"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/features/feature_bind", 
            "pkg_name": "sleekxmpp.features.feature_bind"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/webadmin", 
            "pkg_name": "webadmin"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0065", 
            "pkg_name": "sleekxmpp.plugins.xep_0065"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0066", 
            "pkg_name": "sleekxmpp.plugins.xep_0066"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0108", 
            "pkg_name": "sleekxmpp.plugins.xep_0108"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0060", 
            "pkg_name": "sleekxmpp.plugins.xep_0060"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/herald/herald/transports/http", 
            "pkg_name": "herald.transports.http"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0199", 
            "pkg_name": "sleekxmpp.plugins.xep_0199"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/pelix", 
            "pkg_name": "pelix"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/repositories/python", 
            "pkg_name": "cohorte.repositories.python"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0107", 
            "pkg_name": "sleekxmpp.plugins.xep_0107"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/composer/top/criteria/distance", 
            "pkg_name": "cohorte.composer.top.criteria.distance"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/roster", 
            "pkg_name": "sleekxmpp.roster"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/herald/herald/remote", 
            "pkg_name": "herald.remote"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/composer/top/criteria", 
            "pkg_name": "cohorte.composer.top.criteria"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/google", 
            "pkg_name": "sleekxmpp.plugins.google"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/composer/isolate/agents", 
            "pkg_name": "cohorte.composer.isolate.agents"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/forker", 
            "pkg_name": "cohorte.forker"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0092", 
            "pkg_name": "sleekxmpp.plugins.xep_0092"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0131", 
            "pkg_name": "sleekxmpp.plugins.xep_0131"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/pelix/pelix/remote/transport", 
            "pkg_name": "pelix.remote.transport"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/requests/requests/packages", 
            "pkg_name": "requests.packages"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/boot", 
            "pkg_name": "cohorte.boot"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/composer/node", 
            "pkg_name": "cohorte.composer.node"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp", 
            "pkg_name": "sleekxmpp"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/stanza", 
            "pkg_name": "sleekxmpp.stanza"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0033", 
            "pkg_name": "sleekxmpp.plugins.xep_0033"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0030", 
            "pkg_name": "sleekxmpp.plugins.xep_0030"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/features/feature_preapproval", 
            "pkg_name": "sleekxmpp.features.feature_preapproval"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/pelix/pelix/shell", 
            "pkg_name": "pelix.shell"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/requests/requests", 
            "pkg_name": "requests"
        }, 
        {
            "dir_name": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/serial", 
            "pkg_name": "serial"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/pelix/pelix/remote", 
            "pkg_name": "pelix.remote"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0202", 
            "pkg_name": "sleekxmpp.plugins.xep_0202"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0203", 
            "pkg_name": "sleekxmpp.plugins.xep_0203"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0325/stanza", 
            "pkg_name": "sleekxmpp.plugins.xep_0325.stanza"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/requests/requests/packages/urllib3", 
            "pkg_name": "requests.packages.urllib3"
        }, 
        {
            "dir_name": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/serial/urlhandler", 
            "pkg_name": "serial.urlhandler"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0325", 
            "pkg_name": "sleekxmpp.plugins.xep_0325"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0323", 
            "pkg_name": "sleekxmpp.plugins.xep_0323"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0128", 
            "pkg_name": "sleekxmpp.plugins.xep_0128"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/features/feature_rosterver", 
            "pkg_name": "sleekxmpp.features.feature_rosterver"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/requests", 
            "pkg_name": "requests"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/pelix/pelix", 
            "pkg_name": "pelix"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/instruments", 
            "pkg_name": "cohorte.instruments"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/google/auth", 
            "pkg_name": "sleekxmpp.plugins.google.auth"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0048", 
            "pkg_name": "sleekxmpp.plugins.xep_0048"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0049", 
            "pkg_name": "sleekxmpp.plugins.xep_0049"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0280", 
            "pkg_name": "sleekxmpp.plugins.xep_0280"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0047", 
            "pkg_name": "sleekxmpp.plugins.xep_0047"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/composer", 
            "pkg_name": "cohorte.composer"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/monitor", 
            "pkg_name": "cohorte.monitor"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/composer/node/criteria/distance", 
            "pkg_name": "cohorte.composer.node.criteria.distance"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/repositories", 
            "pkg_name": "cohorte.repositories"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/herald/herald", 
            "pkg_name": "herald"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0191", 
            "pkg_name": "sleekxmpp.plugins.xep_0191"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/composer/isolate", 
            "pkg_name": "cohorte.composer.isolate"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0196", 
            "pkg_name": "sleekxmpp.plugins.xep_0196"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0198", 
            "pkg_name": "sleekxmpp.plugins.xep_0198"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0004/stanza", 
            "pkg_name": "sleekxmpp.plugins.xep_0004.stanza"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/config", 
            "pkg_name": "cohorte.config"
        }, 
        {
            "dir_name": "/home/pi/cohorte/demos/led2/led-raspberry/repo/led_dummy_wrapper/led_dummy_wrapper", 
            "pkg_name": "led_dummy_wrapper"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0016", 
            "pkg_name": "sleekxmpp.plugins.xep_0016"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0013", 
            "pkg_name": "sleekxmpp.plugins.xep_0013"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0012", 
            "pkg_name": "sleekxmpp.plugins.xep_0012"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0257", 
            "pkg_name": "sleekxmpp.plugins.xep_0257"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0060/stanza", 
            "pkg_name": "sleekxmpp.plugins.xep_0060.stanza"
        }, 
        {
            "dir_name": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/serial/tools", 
            "pkg_name": "serial.tools"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0152", 
            "pkg_name": "sleekxmpp.plugins.xep_0152"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0153", 
            "pkg_name": "sleekxmpp.plugins.xep_0153"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/xmlstream/handler", 
            "pkg_name": "sleekxmpp.xmlstream.handler"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/requests/requests/packages/urllib3/util", 
            "pkg_name": "requests.packages.urllib3.util"
        }, 
        {
            "dir_name": "/home/pi/cohorte/demos/led2/led-raspberry/repo/led_dummy_wrapper", 
            "pkg_name": "led_dummy_wrapper"
        }, 
        {
            "dir_name": "/home/pi/cohorte/demos/led2/led-raspberry/repo/led_uno_wrapper", 
            "pkg_name": "led_uno_wrapper"
        }, 
        {
            "dir_name": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial", 
            "pkg_name": "serial"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/utils", 
            "pkg_name": "cohorte.utils"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0221", 
            "pkg_name": "sleekxmpp.plugins.xep_0221"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/java", 
            "pkg_name": "cohorte.java"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0224", 
            "pkg_name": "sleekxmpp.plugins.xep_0224"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/requests/requests/packages/urllib3/contrib", 
            "pkg_name": "requests.packages.urllib3.contrib"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0308", 
            "pkg_name": "sleekxmpp.plugins.xep_0308"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/pelix/pelix/http", 
            "pkg_name": "pelix.http"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/pelix/pelix/internals", 
            "pkg_name": "pelix.internals"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0258", 
            "pkg_name": "sleekxmpp.plugins.xep_0258"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/pelix/pelix/remote/discovery", 
            "pkg_name": "pelix.remote.discovery"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/jsonrpclib/jsonrpclib", 
            "pkg_name": "jsonrpclib"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0020", 
            "pkg_name": "sleekxmpp.plugins.xep_0020"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/requests/requests/packages/chardet", 
            "pkg_name": "requests.packages.chardet"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/pelix/pelix/ipopo/handlers", 
            "pkg_name": "pelix.ipopo.handlers"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0027", 
            "pkg_name": "sleekxmpp.plugins.xep_0027"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/composer/top/criteria/reliability", 
            "pkg_name": "cohorte.composer.top.criteria.reliability"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/cohorte/cohorte/shell", 
            "pkg_name": "cohorte.shell"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0009/stanza", 
            "pkg_name": "sleekxmpp.plugins.xep_0009.stanza"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/pelix/pelix/misc", 
            "pkg_name": "pelix.misc"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0235", 
            "pkg_name": "sleekxmpp.plugins.xep_0235"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/google/gmail", 
            "pkg_name": "sleekxmpp.plugins.google.gmail"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/sleekxmpp/sleekxmpp/plugins/xep_0231", 
            "pkg_name": "sleekxmpp.plugins.xep_0231"
        }, 
        {
            "dir_name": "/home/pi/cohorte/dist/current/repo/herald", 
            "pkg_name": "herald"
        }
    ], 
    "modules": [
        {
            "version": "0.0.0", 
            "name": "pelix.services.configadmin", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/services/configadmin.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.node.criteria", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/node/criteria/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0308.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0308/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0004", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0004/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0009", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0009/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.utils", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/utils/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.shell.composer_top", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/shell/composer_top.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_session.session", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_session/session.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "serial.serialcli", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/serialcli.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.ipopo.handlers.temporal", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/ipopo/handlers/temporal.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.roster.item", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/roster/item.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.remote.herald_xmlrpc", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/remote/herald_xmlrpc.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0030.stanza.info", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0030/stanza/info.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.thirdparty.ordereddict", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/thirdparty/ordereddict.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0065.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0065/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.transports.http.discovery_multicast", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/transports/http/discovery_multicast.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0325", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0325/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0059.rsm", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0059/rsm.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.constants", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/constants.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.google.nosave.nosave", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/google/nosave/nosave.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream.handler", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/handler/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0131", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0131/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0133", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0133.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0323.sensordata", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0323/sensordata.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.test.livesocket", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/test/livesocket.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0054.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0054/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3.util.request", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/util/request.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.boot", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/boot/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.transports.http.servlet", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/transports/http/servlet.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0049", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0049/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.boot.loaders", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/boot/loaders/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream.matcher.many", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/matcher/many.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.misc.eventadmin_printer", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/misc/eventadmin_printer.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.charsetgroupprober", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/charsetgroupprober.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.hebrewprober", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/hebrewprober.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.debug.servlet", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/debug/servlet.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.config.finder", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/config/finder.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.utils", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/utils.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.node.top_store", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/node/top_store.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.forker.starters.exe", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/forker/starters/exe.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.big5freq", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/big5freq.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.escsm", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/escsm.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.remote.discovery", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/remote/discovery/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.framework", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/framework.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "led_dummy_wrapper.led_dummy_wrapper", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/led_dummy_wrapper/led_dummy_wrapper.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.stanza.error", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/stanza/error.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.services", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/services/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.genfolder", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/genfolder.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.utils.multicast", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/utils/multicast.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0221", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0221/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0223", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0223.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0222", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0222.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.langthaimodel", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/langthaimodel.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.sbcsgroupprober", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/sbcsgroupprober.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "serial.serialjava", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/serialjava.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.repositories.java.ipojo", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/repositories/java/ipojo.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_mechanisms.stanza.auth", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_mechanisms/stanza/auth.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.transports", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/transports/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "serial.sermsdos", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/sermsdos.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0131.headers", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0131/headers.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.remote.transport.mqtt_rpc", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/remote/transport/mqtt_rpc.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.node.criteria.reliability.crashing", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/node/criteria/reliability/crashing.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.isolate", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/isolate/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0323.stanza.sensordata", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0323/stanza/sensordata.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3.exceptions", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/exceptions.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0325.stanza.base", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0325/stanza/base.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0033.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0033/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.beans", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/beans.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.ipopo.constants", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/ipopo/constants.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0077.register", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0077/register.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0065.proxy", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0065/proxy.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.remote.xml_rpc", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/remote/xml_rpc.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.shell.ipopo", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/shell/ipopo.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0096.file_transfer", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0096/file_transfer.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0153.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0153/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.euctwfreq", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/euctwfreq.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.boot.loaders.utils", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/boot/loaders/utils.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0084.avatar", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0084/avatar.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0004.dataforms", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0004/dataforms.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0202.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0202/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_bind.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_bind/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_bind", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_bind/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0131.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0131/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.langbulgarianmodel", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/langbulgarianmodel.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.utils.statemachine", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/utils/statemachine.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0050.adhoc", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0050/adhoc.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.componentxmpp", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/componentxmpp.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_starttls", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_starttls/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.roster.single", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/roster/single.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0191.blocking", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0191/blocking.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0184.receipt", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0184/receipt.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.instruments", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/instruments/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.api", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/api.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3.util", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/util/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0308.correction", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0308/correction.py"
        }, 
        {
            "version": "1.3.1", 
            "name": "sleekxmpp.version", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/version.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.google.nosave.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/google/nosave/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.services.eventadmin", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/services/eventadmin.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.node.composer", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/node/composer.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.vote.core", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/vote/core.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream.xmlstream", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/xmlstream.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.structures", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/structures.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.http", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/http/__init__.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.monitor.fsm", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/monitor/fsm.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_mechanisms.stanza.success", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_mechanisms/stanza/success.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0095.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0095/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.shell.remote", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/shell/remote.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3.contrib.pyopenssl", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/contrib/pyopenssl.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "serial.tools.list_ports_linux", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/tools/list_ports_linux.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0184.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0184/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0059.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0059/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0012.last_activity", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0012/last_activity.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0048", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0048/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.monitor.node_starter", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/monitor/node_starter.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0045", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0045.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0047", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0047/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0280.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0280/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.langhungarianmodel", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/langhungarianmodel.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.langcyrillicmodel", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/langcyrillicmodel.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.vote.beans", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/vote/beans.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.remote.discovery.multicast", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/remote/discovery/multicast.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.transports.xmpp.beans", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/transports/xmpp/beans.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.forker.state", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/forker/state.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.charsetprober", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/charsetprober.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "serial.urlhandler.protocol_hwgrep", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/urlhandler/protocol_hwgrep.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.stanza.htmlim", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/stanza/htmlim.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.remote.transport.commons", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/remote/transport/commons.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.boot.loaders.forker", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/boot/loaders/forker.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.top", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/top/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0325.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0325/stanza/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0231.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0231/stanza.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.forker.basic", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/forker/basic.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.remote.transport.jabsorb_rpc", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/remote/transport/jabsorb_rpc.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0009.stanza.RPC", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0009/stanza/RPC.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.exceptions", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/exceptions.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0258.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0258/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.instruments.common", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/instruments/common.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "serial", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0323.device", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0323/device.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_starttls.starttls", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_starttls/starttls.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.big5prober", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/big5prober.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.java.java", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/java/java.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.api", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/api.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.config.reader", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/config/reader.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0319", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0319/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.gb2312freq", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/gb2312freq.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0313", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0313/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.util.sasl.mechanisms", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/util/sasl/mechanisms.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.constants", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/constants.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0198.stream_management", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0198/stream_management.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0060.stanza.pubsub_event", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0060/stanza/pubsub_event.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.shell.forker", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/shell/forker.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0196.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0196/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "serial.tools.list_ports_posix", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/tools/list_ports_posix.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "pelix.misc.jabsorb", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/misc/jabsorb.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3.packages", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/packages/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "serial.serialutil", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/serialutil.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0016.privacy", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0016/privacy.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.node.distributor", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/node/distributor.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/stanza/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_mechanisms.stanza.mechanisms", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_mechanisms/stanza/mechanisms.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0107.user_mood", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0107/user_mood.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.services.fileinstall", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/services/fileinstall.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream.filesocket", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/filesocket.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.top.criteria.distance", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/top/criteria/distance/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.google.auth", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/google/auth/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.stanza.atom", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/stanza/atom.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.monitor.basic", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/monitor/basic.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "jsonrpclib.SimpleJSONRPCServer", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/jsonrpclib/SimpleJSONRPCServer.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.ipopo.instance", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/ipopo/instance.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.shell.xmpp", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/shell/xmpp.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_session", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_session/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream.handler.callback", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/handler/callback.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.thirdparty.mini_dateutil", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/thirdparty/mini_dateutil.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.adapters", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/adapters.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0325.device", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0325/device.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.transports.xmpp.monitor", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/transports/xmpp/monitor.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.config.parser", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/config/parser.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_mechanisms.stanza.failure", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_mechanisms/stanza/failure.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.ipopo.waiting", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/ipopo/waiting.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "jsonrpclib.config", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/jsonrpclib/config.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.utils.ruleengine", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/utils/ruleengine.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0030", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0030/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "led_uno_wrapper.led_uno_wrapper", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/led_uno_wrapper/led_uno_wrapper.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0033", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0033/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream.handler.xmlcallback", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/handler/xmlcallback.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.forker.starters.common", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/forker/starters/common.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0224.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0224/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0071.xhtml_im", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0071/xhtml_im.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0013.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0013/stanza.py"
        }, 
        {
            "version": "3.4.0.2", 
            "name": "requests.packages.urllib3.packages.ssl_match_hostname._implementation", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/packages/ssl_match_hostname/_implementation.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0323.stanza.base", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0323/stanza/base.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3.packages.ordered_dict", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/packages/ordered_dict.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.transports.http.directory", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/transports/http/directory.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream.matcher.xmlmask", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/matcher/xmlmask.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.top.distributor", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/top/distributor.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.forker", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/forker/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.stanza.stream_error", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/stanza/stream_error.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "serial.tools.list_ports_windows", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/tools/list_ports_windows.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.mbcssm", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/mbcssm.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.node.criteria.reliability", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/node/criteria/reliability/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0108", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0108/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.ipv6utils", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/ipv6utils.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream.matcher.xpath", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/matcher/xpath.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.universaldetector", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/universaldetector.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0066.oob", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0066/oob.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.remote.transport", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/remote/transport/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "serial.tools.list_ports_osx", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/tools/list_ports_osx.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0106", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0106.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0107", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0107/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_rosterver.rosterver", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_rosterver/rosterver.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0091.legacy_delay", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0091/legacy_delay.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0186.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0186/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0203.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0203/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "jsonrpclib.history", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/jsonrpclib/history.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.top.composer", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/top/composer.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.boot.looper.default", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/boot/looper/default.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.remote.herald_jsonrpc", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/remote/herald_jsonrpc.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.instruments.node_composer", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/instruments/node_composer.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0030.static", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0030/static.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.forker.starters.cohorte_boot", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/forker/starters/cohorte_boot.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.ipopo.handlers.requires", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/ipopo/handlers/requires.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.shell.composer_node", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/shell/composer_node.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0221.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0221/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.internals", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/internals/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.jpcntx", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/jpcntx.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.test", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/test/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3.util.retry", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/util/retry.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.sjisprober", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/sjisprober.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.remote.discovery.mqtt", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/remote/discovery/mqtt.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0049.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0049/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.codingstatemachine", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/codingstatemachine.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.utils.nt", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/utils/nt.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0191", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0191/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_mechanisms.stanza.abort", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_mechanisms/stanza/abort.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream.matcher", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/matcher/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0319.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0319/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0059", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0059/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.roster", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/roster/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0016.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0016/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.vote.cartoonist", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/vote/cartoonist.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0009.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0009/stanza/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.top.criteria.reliability", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/top/criteria/reliability/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3.contrib.ntlmpool", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/contrib/ntlmpool.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream.matcher.stanzapath", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/matcher/stanzapath.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.google.auth.auth", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/google/auth/auth.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.latin1prober", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/latin1prober.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.remote", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/remote/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.test.mocksocket", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/test/mocksocket.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "serial.tools.list_ports", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/tools/list_ports.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.google.auth.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/google/auth/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.config", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/config/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0086.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0086/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0050", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0050/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0115.caps", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0115/caps.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3.util.url", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/util/url.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream.scheduler", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/scheduler.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.ipopo.handlers.provides", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/ipopo/handlers/provides.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_rosterver.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_rosterver/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0325.stanza.control", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0325/stanza/control.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0152.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0152/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0027.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0027/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.remote.herald_jabsorbrpc", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/remote/herald_jabsorbrpc.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_mechanisms.stanza.response", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_mechanisms/stanza/response.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_mechanisms.stanza.challenge", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_mechanisms/stanza/challenge.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0202.time", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0202/time.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0224", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0224/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0221.media", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0221/media.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0071.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0071/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.remote.dispatcher", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/remote/dispatcher.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "webadmin", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/webadmin/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0004.stanza.field", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0004/stanza/field.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.node.beans", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/node/beans.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.base", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/base.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.utils.posix", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/utils/posix.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream.handler.xmlwaiter", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/handler/xmlwaiter.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.node.distributor_csp", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/node/distributor_csp.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.shell", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/shell.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.models", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/models.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "led_dummy_wrapper", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/led_dummy_wrapper/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0153.vcard_avatar", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0153/vcard_avatar.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.euckrprober", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/euckrprober.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.basexmpp", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/basexmpp.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.util.misc_ops", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/util/misc_ops.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0078.legacyauth", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0078/legacyauth.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0027.gpg", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0027/gpg.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.clientxmpp", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/clientxmpp.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.stanza.nick", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/stanza/nick.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.node.commander", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/node/commander.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.boot.looper", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/boot/looper/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0071", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0071/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0048.bookmarks", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0048/bookmarks.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0270", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0270.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0297.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0297/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0078", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0078/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_mechanisms.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_mechanisms/stanza/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.jid", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/jid.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.boot.loaders.osgi_inner", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/boot/loaders/osgi_inner.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.auth", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/auth.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0153", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0153/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0152", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0152/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.java", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/java/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.thirdparty.statemachine", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/thirdparty/statemachine.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0009.binding", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0009/binding.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0092", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0092/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0091", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0091/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0096", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0096/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.transports.http", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/transports/http/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0095", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0095/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0258", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0258/__init__.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.repositories.java.manifest", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/repositories/java/manifest.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0256", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0256.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0257", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0257/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.ipopo.contexts", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/ipopo/contexts.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.remote.registry", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/remote/registry.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0060.stanza.base", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0060/stanza/base.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.transports.http.transport", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/transports/http/transport.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_rosterver", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_rosterver/__init__.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.boot.boot", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/boot/boot.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.parser", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/parser.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.compat", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/compat.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0199.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0199/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream.handler.waiter", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/handler/waiter.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0319.idle", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0319/idle.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0323", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0323/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0066.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0066/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_preapproval.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_preapproval/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.transports.http.beans", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/transports/http/beans.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.top.status", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/top/status.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.test.sleektest", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/test/sleektest.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.vote.presidentielle", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/vote/presidentielle.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.shell.eventadmin", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/shell/eventadmin.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.sessions", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/sessions.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.forker.state_updater", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/forker/state_updater.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.thirdparty", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/thirdparty/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.jisfreq", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/jisfreq.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.remote.discovery.mdns", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/remote/discovery/mdns.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.utils", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/utils.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3.fields", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/fields.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0313.mam", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0313/mam.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.repositories.python", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/repositories/python/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.node.status", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/node/status.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0118.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0118/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0060.pubsub", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0060/pubsub.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0091.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0091/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.core", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/core.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.forker.starters", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/forker/starters/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.monitor", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/monitor/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0030.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0030/stanza/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.transports.xmpp.directory", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/transports/xmpp/directory.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0047.stream", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0047/stream.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0060.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0060/stanza/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_starttls.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_starttls/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.ipopo.decorators", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/ipopo/decorators.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.repositories.java.bundles", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/repositories/java/bundles.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0085.chat_states", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0085/chat_states.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0172.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0172/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "jsonrpclib.jsonclass", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/jsonrpclib/jsonclass.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.google.gmail", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/google/gmail/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.exceptions", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/exceptions.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0085.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0085/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.status_codes", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/status_codes.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0279.ipcheck", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0279/ipcheck.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.transports.xmpp.bot", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/transports/xmpp/bot.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "jsonrpclib", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/jsonrpclib/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "serial.urlhandler.protocol_rfc2217", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/urlhandler/protocol_rfc2217.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.gmail_notify", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/gmail_notify.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0078.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0078/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.node", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/node/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.util.stringprep_profiles", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/util/stringprep_profiles.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "serial.rfc2217", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/rfc2217.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.google", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/google/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.remote", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/remote/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.transports.xmpp.utils", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/transports/xmpp/utils.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream.tostring", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/tostring.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0297", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0297/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0118", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0118/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0115", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0115/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "jsonrpclib.utils", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/jsonrpclib/utils.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.directory", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/directory.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3._collections", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/_collections.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0184", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0184/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0186", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0186/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "serial.tools", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/tools/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3.connection", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/connection.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0258.security_labels", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0258/security_labels.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0020", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0020/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0027", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0027/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0060.stanza.pubsub", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0060/stanza/pubsub.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0235.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0235/stanza.py"
        }, 
        {
            "version": "2.5.0", 
            "name": "requests", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_preapproval", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_preapproval/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0203", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0203/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0202", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0202/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0257.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0257/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream.handler.base", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/handler/base.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0323.timerreset", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0323/timerreset.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0163", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0163.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "jsonrpclib.jsonrpc", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/jsonrpclib/jsonrpc.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0092.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0092/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.remote.discovery", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/remote/discovery.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0323.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0323/stanza/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0313.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0313/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.transports.xmpp.transport", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/transports/xmpp/transport.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0203.delay", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0203/delay.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.isolate.agents.ipopo", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/isolate/agents/ipopo.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.threadpool", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/threadpool.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3.connectionpool", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/connectionpool.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream.matcher.base", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/matcher/base.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0009.remote", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0009/remote.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.internals.events", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/internals/events.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0092.version", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0092/version.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.internals.registry", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/internals/registry.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.shell.console", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/shell/console.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.euctwprober", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/euctwprober.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3.util.ssl_", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/util/ssl_.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0048.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0048/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0004.stanza.form", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0004/stanza/form.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.util.sasl.client", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/util/sasl/client.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.google.settings.settings", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/google/settings/settings.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0047.ibb", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0047/ibb.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_mechanisms", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_mechanisms/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.google.gmail.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/google/gmail/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "webadmin.webadmin", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/webadmin/webadmin.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.services.mqtt", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/services/mqtt.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream.matcher.idsender", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/matcher/idsender.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.shell.agent", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/shell/agent.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3.filepost", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/filepost.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.mbcsgroupprober", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/mbcsgroupprober.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0080.geoloc", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0080/geoloc.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0186.invisible_command", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0186/invisible_command.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.util", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/util/__init__.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.repositories.python.modules", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/repositories/python/modules.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.stanza.presence", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/stanza/presence.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0108.user_activity", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0108/user_activity.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3.util.response", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/util/response.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.debug", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/debug/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.node.criteria.reliability.timer", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/node/criteria/reliability/timer.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0020.feature_negotiation", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0020/feature_negotiation.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0077.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0077/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.instruments.servlet", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/instruments/servlet.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0086.legacy_error", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0086/legacy_error.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.sbcharsetprober", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/sbcharsetprober.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.ipopo.handlers.constants", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/ipopo/handlers/constants.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.ipopo.core", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/ipopo/core.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.misc.mqtt_client", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/misc/mqtt_client.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.google.nosave", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/google/nosave/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0012", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0012/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0013", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0013/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0016", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0016/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0096.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0096/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0257.client_cert_management", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0257/client_cert_management.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.hooks", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/hooks.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.chardistribution", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/chardistribution.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0066", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0066/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0065", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0065/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0095.stream_initiation", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0095/stream_initiation.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0060", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0060/__init__.py"
        }, 
        {
            "version": "0.2.9", 
            "name": "sleekxmpp.thirdparty.gnupg", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/thirdparty/gnupg.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0077", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0077/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0020.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0020/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0198.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0198/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.utilities", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/utilities.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.repositories.beans", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/repositories/beans.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0249.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0249/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0004.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0004/stanza/__init__.py"
        }, 
        {
            "version": "1.2.0", 
            "name": "requests.packages.urllib3.packages.six", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/packages/six.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.remote.json_rpc", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/remote/json_rpc.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0050.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0050/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_preapproval.preapproval", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_preapproval/preapproval.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0080", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0080/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0082", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0082.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0085", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0085/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0084", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0084/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0128", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0128/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0086", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0086/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "led_uno_wrapper", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/led_uno_wrapper/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0249.invite", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0249/invite.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0249", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0249/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.exceptions", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/exceptions.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0242", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0242.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.boot.looper.qt", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/boot/looper/qt.py"
        }, 
        {
            "version": "2.3.0", 
            "name": "requests.packages.chardet", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.stanza.roster", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/stanza/roster.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0172.user_nick", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0172/user_nick.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_bind.bind", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_bind/bind.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.misc.xmpp", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/misc/xmpp.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.services.eventadmin_mqtt", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/services/eventadmin_mqtt.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0128.static", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0128/static.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.langhebrewmodel", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/langhebrewmodel.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.ipopo.handlers", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/ipopo/handlers/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.vote.dummy_store", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/vote/dummy_store.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.vote", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/vote/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "serial.serialposix", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/serialposix.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.shell.beans", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/shell/beans.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0107.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0107/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream.handler.collector", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/handler/collector.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0231", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0231/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.isolate.agents", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/isolate/agents/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0235", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0235/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.utf8prober", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/utf8prober.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.remote.beans", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/remote/beans.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.boot.constants", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/boot/constants.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3.response", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/response.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.node.criteria.distance.history", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/node/criteria/distance/history.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0191.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0191/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_mechanisms.mechanisms", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_mechanisms/mechanisms.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.cp949prober", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/cp949prober.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0280.carbons", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0280/carbons.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3.request", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/request.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.ipopo", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/ipopo/__init__.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.forker.watchers", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/forker/watchers.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0199.ping", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0199/ping.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3.contrib", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/contrib/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.node.finder", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/node/finder.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.stanza.message", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/stanza/message.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.top.commander", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/top/commander.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.gb2312prober", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/gb2312prober.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.top.criteria.distance.configuration", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/top/criteria/distance/configuration.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.features.feature_session.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/features/feature_session/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.euckrfreq", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/euckrfreq.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "serial.tools.miniterm", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/tools/miniterm.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.ipopo.handlers.requiresbest", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/ipopo/handlers/requiresbest.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.node.criteria.distance.configuration", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/node/criteria/distance/configuration.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.shell", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/shell/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.repositories", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/repositories/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.top.criteria.distance.language", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/top/criteria/distance/language.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "serial.win32", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/win32.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.eucjpprober", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/eucjpprober.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.langgreekmodel", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/langgreekmodel.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "serial.urlhandler", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/urlhandler/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.vote.servlet", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/vote/servlet.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "serial.urlhandler.protocol_loop", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/urlhandler/protocol_loop.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0235.oauth", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0235/oauth.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.cookies", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/cookies.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0084.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0084/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.ipopo.handlers.properties", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/ipopo/handlers/properties.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "serial.urlhandler.protocol_socket", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/urlhandler/protocol_socket.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.stanza.stream_features", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/stanza/stream_features.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.stanza.rootstanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/stanza/rootstanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.misc", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/misc/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0297.forwarded", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0297/forwarded.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.chardetect", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/chardetect.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0013.offline", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0013/offline.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.boot.loaders.broker", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/boot/loaders/broker.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.monitor.status", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/monitor/status.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0047.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0047/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.http.basic", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/http/basic.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0128.extended_disco", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0128/extended_disco.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream.matcher.id", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/matcher/id.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "serial.serialwin32", 
            "language": "python", 
            "filename": "/home/pi/cohorte/demos/led2/led-raspberry/repo/serial/serialwin32.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3.packages.ssl_match_hostname", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/packages/ssl_match_hostname/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0196.user_gaming", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0196/user_gaming.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.node.history", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/node/history.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.repositories.python.ipopo", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/repositories/python/ipopo.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0196", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0196/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.ipopo.handlers.requiresmap", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/ipopo/handlers/requiresmap.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0030.disco", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0030/disco.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0060.stanza.pubsub_owner", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0060/stanza/pubsub_owner.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0054", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0054/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0231.bob", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0231/bob.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.node.criteria.distance", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/node/criteria/distance/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0199", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0199/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0198", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0198/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0224.attention", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0224/attention.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0115.static", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0115/static.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.isolate.composer", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/isolate/composer.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0152.reachability", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0152/reachability.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0033.addresses", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0033/addresses.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0060.stanza.pubsub_errors", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0060/stanza/pubsub_errors.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream.cert", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/cert.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0172", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0172/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0279", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0279/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.compat", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/compat.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.node.criteria.distance.compatibility", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/node/criteria/distance/compatibility.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream.stanzabase", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/stanzabase.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.roster.multi", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/roster/multi.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0115.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0115/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.top.criteria", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/top/criteria/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream.resolver", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/resolver.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.boot.loaders.pelix_inner", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/boot/loaders/pelix_inner.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.vote.approbation", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/vote/approbation.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0280", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0280/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.mbcharsetprober", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/mbcharsetprober.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.utils.vote", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/utils/vote.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.repositories.java", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/repositories/java/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0054.vcard_temp", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0054/vcard_temp.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.google.gmail.notifications", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/google/gmail/notifications.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0308", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0308/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0302", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0302.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.vote.alternative", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/vote/alternative.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.shell", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/shell/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0080.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0080/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.thirdparty.socks", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/thirdparty/socks.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.transports.xmpp", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/transports/xmpp/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.isolate.status", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/isolate/status.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.util.sasl", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/util/sasl/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "herald.beans", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/herald/beans.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0012.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0012/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.chardet.escprober", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/chardet/escprober.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.ldapfilter", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/ldapfilter.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.forker.broker", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/forker/broker.py"
        }, 
        {
            "version": "1.0.0", 
            "name": "cohorte.monitor.agent", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/monitor/agent.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0030.stanza.items", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0030/stanza/items.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0325.control", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0325/control.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3.util.timeout", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/util/timeout.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0009.rpc", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0009/rpc.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.composer.top.store_handler", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/composer/top/store_handler.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3.poolmanager", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/poolmanager.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "cohorte.boot.looper.cocoa", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/cohorte/boot/looper/cocoa.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.shell.configadmin", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/shell/configadmin.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.packages.urllib3.util.connection", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/packages/urllib3/util/connection.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0049.private_storage", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0049/private_storage.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.shell.core", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/shell/core.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0279.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0279/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "requests.certs", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/requests/certs.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0108.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0108/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.xmlstream.jid", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/xmlstream/jid.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.stanza.iq", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/stanza/iq.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.google.settings.stanza", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/google/settings/stanza.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.google.settings", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/google/settings/__init__.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "pelix.remote.edef_io", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/pelix/remote/edef_io.py"
        }, 
        {
            "version": "0.0.0", 
            "name": "sleekxmpp.plugins.xep_0118.user_tune", 
            "language": "python", 
            "filename": "/home/pi/cohorte/dist/cohorte-1.0.0-20141216.234517-57-python-distribution/repo/sleekxmpp/plugins/xep_0118/user_tune.py"
        }
    ]
}