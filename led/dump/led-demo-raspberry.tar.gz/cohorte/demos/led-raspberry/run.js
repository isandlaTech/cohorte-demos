{
    "node": {
        "use-cache": "true",
        "name": "led-raspberry",
        "top-composer": false,
        "interpreter": "python",
        "web-admin": 0,
        "recomposition-delay": 150,
        "shell-admin": 0
    },
    "application-id": "led",
    "transport-xmpp": {
      "xmpp-server": "charmanson.isandlatech.com",
      "xmpp-jid": "bot@charmanson.isandlatech.com",
      "xmpp-port": 5222
    },
    "transport": [
        "xmpp"
    ]
}
