extract this archive file into /home/pi 
(other else, you should update "demo" and "demo2" scripts to have your current home path).

"demo" script starts the led demo using XMPP protocol
"demo2" starts the led demo using HTTP protocol
