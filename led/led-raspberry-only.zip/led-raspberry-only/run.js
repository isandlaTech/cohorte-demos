{
    "node": {
        "use-cache": "true",
        "name": "led-raspberry-only",
        "top-composer": true,
        "interpreter": "python",
        "web-admin": 9000,
        "recomposition-delay": 150,
        "shell-admin": 90001
    },
    "application-id": "led-raspberry-only",
    "transport": [
        "http"
    ],
    "transport-http": {
      "http-ipv": 4
    }
}