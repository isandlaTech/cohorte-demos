/* WARNING!: do not edit, this file is generated automatically by COHORTE startup scripts. */
{
    "composition" : [
    {
        "name" : "pelix-http-service",
        "properties" : {
            "pelix.http.port" : 7777
        }
    }
    ]
}
